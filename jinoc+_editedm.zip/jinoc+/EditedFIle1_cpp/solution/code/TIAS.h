

#ifndef __TOKENIZE_H
#define __TOKENIZE_H

#include <stddef.h>



size_t str_tokenize(char*, char**, const size_t);

#endif /* __TOKENIZE_H */
